{-# OPTIONS_GHC -Wno-overlapping-patterns #-}
module Hw3 where

type Symbol = String
data Expr = Var Symbol
          | App Expr Expr
          | Lambda Symbol Expr deriving Eq

instance Show Expr where
    show (Var x) = x
    show (App e1 e2) = "(" ++ show e1 ++ " " ++ show e2 ++ ")"
    show (Lambda x e) = "(\\" ++  x ++ "." ++ show e ++ ")"  

doSubstitution :: Symbol -> Expr -> Expr -> Expr  
doSubstitution x (App e1 e2) (Var y) = App (doSubstitution x e1 (Var y)) (doSubstitution x e2 (Var y))
doSubstitution x (Var y) (Var z) | x == y = Var z
                                 | otherwise = Var y
doSubstitution x (Var y) e | x == y = e
                           | otherwise = Var y
doSubstitution x (Lambda y e) (Var z) | x == y = Lambda y e
                                      | otherwise = Lambda y (doSubstitution x e (Var z))
doSubstitution x (Lambda y e1) e2 | x == y = Lambda y e1
                                  | otherwise = Lambda y (doSubstitution x e1 e2)
doSubstitution x (App e1 e2) e = App (doSubstitution x e1 e) (doSubstitution x e2 e)
doSubstitution x e (App e1 e2) = App (doSubstitution x e e1) (doSubstitution x e e2)

-- Function to evaluate an expression
eval :: Expr -> Expr
eval e | e == e' = e
       | otherwise = eval e'
    where e' = reduce e

reduce :: Expr -> Expr
reduce (Var x) = Var x                                    -- Var "x"
reduce (App (Lambda x e1) e2) = doSubstitution x e1 e2    -- (App (Lambda x (...)) (...))
reduce (App e1 e2) = App (eval e1)  (eval e2)             -- App (App / Var ...) (App / Var ...)
reduce (Lambda x e) = Lambda x (eval e)                   -- Lambda "x" (...)


one = Lambda "s" (Lambda "z" (App (Var "s") (Var "z")))
suc = Lambda "w"
       (Lambda "y"
         (Lambda "x"
           (App (Var "y")
                (App (App (Var "w") (Var "y"))
                     (Var "x")))))

-- eval (App (Lambda "x" (Var "x")) (Var "y")) --> y
-- eval (App (Lambda "x" (Var "x")) (App (Var "x") (Var "y"))) --> (x y)
-- (λx. (λy. x y))(x)
-- eval (App (Lambda "x" (Lambda "y" (App (Var "x") (Var "y")))) (Var "x"))
-- eval (App (Lambda "x" (Lambda "y" (App (Var "x") (Var "y")))) (Var "z")) --> (\y.(zy))
-- eval (App (Lambda "x" (App (Var "y") (Lambda "y" (App (Var "x") (Var "y"))))) (Var "z")) --> (y (\y.(zy)))
-- eval (App (Lambda "x" (App (Var "x") (Lambda "y" (App (Var "x") (Var "y"))))) (Var "z")) --> (z (\y.(zy))) 
-- eval (App (Lambda "x" (Var "x")) (Var "y")) --> y
-- eval (App (Lambda "x" (Var "x")) (Lambda "x" (Var "x"))) --> (\x.x)
-- eval (App (Lambda "x" (Lambda "y" (Var "x"))) (Lambda "x" (Var "x"))) --> ((\y.(\x.x)))
-- eval (App (Lambda "x" (Lambda "x" (Var "x"))) (Lambda "x" (Var "x"))) --> (\x.x)
-- eval (App (Lambda "x" (Lambda "x" (Var "x"))) (Var "z")) --> (\x.x)
-- eval (App (Lambda "x" (Lambda "x" (Var "x"))) (Lambda "x" (Var "x"))) --> (\x.x)
-- eval (App suc one) --> (\y.(\x.(y (y x))))

t1 = App (Var "x") (Var "y") --(x y)
t2 = Lambda "x" (Var "x") -- (\x.x)
t3 = App (Lambda "x" (Var "x")) (Var "y") -- y
t4 = App suc one -- (\y.(\x.(y (y x))))
t5 = App (Lambda "x" (Lambda "x" (Var "x"))) (Lambda "x" (Var "x")) -- (\x.x)
t6 = App (Lambda "x" (Lambda "x" (Var "x"))) (Var "z") -- (\x.x)
t7 = App (Lambda "x" (Lambda "x" (Var "x"))) (Lambda "x" (Var "x")) -- (\x.x)
t8 = App (Lambda "x" (Lambda "y" (Var "x"))) (Lambda "x" (Var "x")) -- (\y.(\x.x))
t9 = App (Lambda "x" (Var "x")) (Lambda "x" (Var "x")) -- (\x.x)
t10 = App (Lambda "x" (Lambda "y" (App (Var "x") (Var "y")))) (Var "z") -- (\y.(z y))
t11 = App (Lambda "x" (App (Var "y") (Lambda "y" (App (Var "x") (Var "y"))))) (Var "z") -- (y (\y.(z y)))
t12 = App (Lambda "x" (App (Var "x") (Lambda "y" (App (Var "x") (Var "y"))))) (Var "z") -- (z (\y.(zy))) 