module Hw3 where

type Symbol = String
data Expr = Var Symbol
            | App Expr Expr
            | Lambda Symbol Expr deriving Eq

instance Show Expr where
    show (Var x) = x
    show (App e1 e2) = "(" ++ show e1 ++ " " ++ show e2 ++ ")"
    show (Lambda x e) = "(\\" ++  x ++ "." ++ show e ++ ")"  

eval :: Expr -> Expr
eval e = e