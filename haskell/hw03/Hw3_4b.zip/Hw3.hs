{-# OPTIONS_GHC -Wno-overlapping-patterns #-}
module Hw3 where

type Symbol = String
data Expr = Var Symbol
          | App Expr Expr
          | Lambda Symbol Expr deriving Eq

instance Show Expr where
    show (Var x) = x
    show (App e1 e2) = "(" ++ show e1 ++ " " ++ show e2 ++ ")"
    show (Lambda x e) = "(\\" ++  x ++ "." ++ show e ++ ")"  

doSubstitution :: Symbol -> Expr -> Expr -> Expr
doSubstitution x e (Var y) | x == y = e
                           | otherwise = Var y -- Here is problem eval (App (Lambda "x" (Lambda "y" (App (Var "x") (Var "y")))) (Var "y"))
doSubstitution x e (App e1 e2) = App (doSubstitution x e e1) (doSubstitution x e e2)


eval :: Expr -> Expr
eval (Var x) = Var x                                    -- Var "x"
eval (App (Lambda x e1) e2) = doSubstitution x e1 e2    -- (App (Lambda x (...)) (...))
eval (App e1 e2) = App (eval e1)  (eval e2)             -- App (...) (...)
eval (Lambda x e) = Lambda x (eval e)                   -- Lambda "x" (...)


-- eval (App (Lambda "x" (Var "x")) (Var "y")) --> y
-- eval (App (Lambda "x" (Var "x")) (App (Var "x") (Var "y"))) --> (x y)
-- (λx. (λy. x y))(x)
-- eval (App (Lambda "x" (Lambda "y" (App (Var "x") (Var "y")))) (Var "x"))